<template>
    <div>
        <div class="col-span-1">
            <div class="rounded-t-lg text-center py-2 bg-primary">
                <h3 class="text-xl font-semibold">Configurações</h3>
            </div>
            <div class="rounded-b-lg bg-base-300 p-4">
                <ul class="space-y-8">
                    <li><a href="/user/profile">Editar Perfil</a></li>
                    <li><a>Assista Novamente</a></li>
                    <li><a href="/user/favorites/movie">Filmes Favoritos</a></li>
                    <li><a href="/user/favorites/serie">Series Favoritas</a></li>
                    <li class="text-red-500 font-bold"><a>Excluir Conta</a></li>
                </ul>
            </div>
        </div>
    </div>
</template>
